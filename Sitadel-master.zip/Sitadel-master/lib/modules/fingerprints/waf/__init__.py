from lib.utils.output import Output

Output().info("For better waf detection we recommend you to run with --no-redirect")

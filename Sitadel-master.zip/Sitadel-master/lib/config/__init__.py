from .settings import Settings

# Main object to hold the configuration
settings = Settings()
